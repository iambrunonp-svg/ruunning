export default class GameManager {
  constructor(renderer, game, battle, audio) {
    this.renderer = renderer;
    this.game = game;       // opcional, pode ser null
    this.battle = battle;
    this.audio = audio;

    this.currentPhase = null;
    this.targetPhase = null;
    this.fadeElement = document.getElementById("fade");
    this.isTransitioning = false;
  }

  requestPhaseChange(phaseName){
    if(this.isTransitioning || this.currentPhase === phaseName) return;
    this.targetPhase = phaseName;
    this.startFadeOut();
    this.fadeAudioOut();
  }

  fadeAudioOut(){
    const fade = setInterval(() => {
      if(this.audio.volume > 0.05) this.audio.volume -= 0.05;
      else { this.audio.volume=0; clearInterval(fade);}
    },50);
  }

  fadeAudioIn(){
    const fade = setInterval(() => {
      if(this.audio.volume < 0.95) this.audio.volume +=0.05;
      else {this.audio.volume=1; clearInterval(fade);}
    },50);
  }

  startFadeOut(){
    this.isTransitioning = true;
    this.fadeElement.style.opacity = 1;
    setTimeout(()=>this.switchPhase(), 600);
  }

  switchPhase(){
    if(this.currentPhase === "game" && this.game) this.game.stop();
    if(this.currentPhase === "battle" && this.battle) this.battle.stop();

    this.currentPhase = this.targetPhase;

    if(this.currentPhase === "game" && this.game) this.game.start(this.renderer);
    if(this.currentPhase === "battle" && this.battle) {
      this.audio.src = "audio/battle_music.mp3";
      this.battle.start(this.renderer);
    }

    this.audio.play();
    this.fadeAudioIn();
    this.startFadeIn();
  }

  startFadeIn(){
    this.fadeElement.style.opacity = 0;
    setTimeout(()=>this.isTransitioning=false, 600);
  }

  update(){
    if(this.currentPhase === "game" && this.game) this.game.update();
    if(this.currentPhase === "battle" && this.battle) this.battle.update();
  }

  // Shake de câmera
  applyCameraShake(camera, intensity=0.2, duration=0.3){
    const start = performance.now();
    const original = camera.position.clone();
    const shake = () => {
      const now = performance.now();
      const t = (now-start)/1000;
      if(t<duration){
        camera.position.x = original.x + (Math.random()-0.5)*intensity;
        camera.position.y = original.y + (Math.random()-0.5)*intensity;
        requestAnimationFrame(shake);
      } else camera.position.copy(original);
    }
    shake();
  }
}
