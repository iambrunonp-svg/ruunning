// Assumes ES module imports outside this file:
// import * as THREE from 'three';
// import { EffectComposer } from 'three/examples/jsm/postprocessing/EffectComposer.js';
// import { RenderPass } from 'three/examples/jsm/postprocessing/RenderPass.js';
// import { UnrealBloomPass } from 'three/examples/jsm/postprocessing/UnrealBloomPass.js';

const BATTLE_CONFIG = {
    PLAYER_HEALTH: 100,
    PLAYER_MAX_HEALTH: 100,
    PLAYER_MOVE_SPEED: 12,
    PLAYER_DEPTH_SPEED: 10,
    PLAYER_SHOOT_COOLDOWN: 0.18,
    PLAYER_PROJECTILE_DAMAGE: 12,
    PLAYER_PROJECTILE_SPEED: -90,

    BOSS_HEALTH: 150,
    BOSS_MAX_HEALTH: 150,
    BOSS_ATTACK_TIMER_NORMAL: 2.0,
    BOSS_ATTACK_TIMER_ENRAGED: 1.3,
    PROJECTILE_DAMAGE_MISSILE: 15,
    PROJECTILE_DAMAGE_LASER: 10,
    PROJECTILE_DAMAGE_SHARD: 5,
};

class ArchitectBattle {
    constructor(canvas, onBattleEnd) {
        this.canvas = canvas;
        this.onBattleEnd = onBattleEnd;

        // Core three
        this.scene = null;
        this.camera = null;
        this.renderer = null;
        this.clock = new THREE.Clock();
        this.animationFrameId = null;

        // Postprocessing
        this.composer = null;

        // Entities
        this.player = null;
        this.architect = null;
        this.projectiles = [];

        // Particles (pool)
        this.particlePool = [];
        this.particles = [];

        // Game state
        this.keysPressed = {};
        this.state = {
            playerHealth: BATTLE_CONFIG.PLAYER_HEALTH,
            playerMaxHealth: BATTLE_CONFIG.PLAYER_MAX_HEALTH,
            bossHealth: BATTLE_CONFIG.BOSS_HEALTH,
            bossMaxHealth: BATTLE_CONFIG.BOSS_MAX_HEALTH,
            isEnraged: false,
            lastPlayerHitTime: 0
        };

        // UI
        this.ui = {};
    }

    start() {
        this._initScene();
        this._initPlayer();
        this._initArchitect();
        this._initParticlePool(400);
        this._initPostProcessing();
        this._createUI();

        this._setupEventListeners();
        this.animationFrameId = requestAnimationFrame(() => this.animate());
        console.log("Architect Battle initiated with Three.js (ES modules)!");
    }

    stop(playerWon) {
        if (this.animationFrameId) cancelAnimationFrame(this.animationFrameId);
        this._removeEventListeners();

        if (this.composer) {
            // composer doesn't have dispose method; we can clean renderer
            this.composer = null;
        }
        if (this.renderer) {
            this.renderer.dispose();
            this.renderer.forceContextLoss();
        }

        // clear references
        this.scene = null;
        this.camera = null;
        this.renderer = null;
        this.projectiles = [];
        this.particles = [];
        this.particlePool = [];
        this.keysPressed = {};

        // remove UI dom if exists
        if (this.ui.container && this.ui.container.parentNode) {
            this.ui.container.parentNode.removeChild(this.ui.container);
        }

        this.onBattleEnd(playerWon);
    }

    getHealthStatus() {
        return {
            player: { current: this.state.playerHealth, max: this.state.playerMaxHealth },
            boss: { current: this.state.bossHealth, max: this.state.bossMaxHealth }
        };
    }

    // ---------- Initialization ----------
    _initScene() {
        this.scene = new THREE.Scene();
        // cibernetic theme: deep purple background
        this.scene.background = new THREE.Color(0x0b0012);
        this.scene.fog = new THREE.Fog(0x0b0012, 25, 80);

        this.renderer = new THREE.WebGLRenderer({ canvas: this.canvas, antialias: true, alpha: false });
        this.renderer.setSize(this.canvas.width, this.canvas.height);
        this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
        this.renderer.toneMappingExposure = 1.0;

        this.camera = new THREE.PerspectiveCamera(70, this.canvas.width / this.canvas.height, 0.1, 1000);
        this.camera.position.set(0, 6, 18);
        this.camera.lookAt(0, 2, 0);

        // Lights (neon accents)
        const ambient = new THREE.AmbientLight(0xffffff, 0.25);
        this.scene.add(ambient);

        const rim = new THREE.PointLight(0x9b59ff, 1.4, 60);
        rim.position.set(-10, 12, 10);
        this.scene.add(rim);

        const accent = new THREE.PointLight(0xff2dff, 0.8, 40);
        accent.position.set(10, 6, -10);
        this.scene.add(accent);

        // Floor (glossy path)
        const road = new THREE.Mesh(
            new THREE.PlaneGeometry(30, 80),
            new THREE.MeshStandardMaterial({
                color: 0x111116,
                metalness: 0.6,
                roughness: 0.2
            })
        );
        road.rotation.x = -Math.PI / 2;
        road.position.y = 0;
        this.scene.add(road);
    }

    _initPlayer() {
        // Player group with subtle neon rim
        const playerGroup = new THREE.Group();
        const body = new THREE.Mesh(
            new THREE.CapsuleGeometry(0.8, 1.2, 4, 16),
            new THREE.MeshStandardMaterial({ color: 0x5dafff, emissive: 0x05283a, metalness: 0.2, roughness: 0.3 })
        );
        body.position.y = 1.6;
        playerGroup.add(body);

        const visor = new THREE.Mesh(
            new THREE.BoxGeometry(1.2, 0.4, 0.4),
            new THREE.MeshStandardMaterial({ color: 0x00f0ff, emissive: 0x003344, emissiveIntensity: 1.5 })
        );
        visor.position.set(0, 2.0, 0.6);
        playerGroup.add(visor);

        this.player = {
            mesh: playerGroup,
            moveSpeed: BATTLE_CONFIG.PLAYER_MOVE_SPEED,
            depthSpeed: BATTLE_CONFIG.PLAYER_DEPTH_SPEED,
            shootCooldown: BATTLE_CONFIG.PLAYER_SHOOT_COOLDOWN,
            shootTimer: 0
        };
        this.player.mesh.position.set(0, 0, 12);
        this.scene.add(this.player.mesh);
    }

    _initArchitect() {
        const architectGroup = new THREE.Group();

        const core = new THREE.Mesh(
            new THREE.IcosahedronGeometry(2.5, 1),
            new THREE.MeshStandardMaterial({
                color: 0xff00ff,
                emissive: 0x880066,
                emissiveIntensity: 1.8,
                metalness: 0.4,
                roughness: 0.15,
                flatShading: true
            })
        );
        architectGroup.add(core);

        // shards
        for (let i = 0; i < 6; i++) {
            const shard = new THREE.Mesh(
                new THREE.BoxGeometry(0.5, 2, 0.5),
                new THREE.MeshStandardMaterial({ color: 0xff66ff, emissive: 0x330033, emissiveIntensity: 0.8 })
            );
            const angle = (i / 6) * Math.PI * 2;
            shard.position.set(Math.cos(angle) * 4.2, 0, Math.sin(angle) * 4.2);
            shard.lookAt(core.position);
            architectGroup.add(shard);
        }

        this.architect = {
            mesh: architectGroup,
            attackTimer: BATTLE_CONFIG.BOSS_ATTACK_TIMER_NORMAL,
            shards: architectGroup.children.slice(1),
            phaseTimer: 0,
            lastWarpTime: 0
        };
        this.architect.mesh.position.set(0, 5, -20);
        this.scene.add(this.architect.mesh);
    }

    // ---------- Particle Pool ----------
    _initParticlePool(maxParticles = 300) {
        this.particlePool = [];
        this.particles = [];

        const geometry = new THREE.SphereGeometry(0.055, 6, 6);
        for (let i = 0; i < maxParticles; i++) {
            const material = new THREE.MeshStandardMaterial({
                color: 0xffffff,
                emissive: 0xffffff,
                emissiveIntensity: 1,
                transparent: true,
                opacity: 1
            });
            const p = new THREE.Mesh(geometry, material);
            p.visible = false;
            this.particlePool.push(p);
            this.scene.add(p);
        }
    }

    _spawnParticles(position, color = 0xffffff, count = 12, scale = 1) {
        for (let i = 0; i < count; i++) {
            if (this.particlePool.length === 0) return;
            const pMesh = this.particlePool.pop();
            pMesh.visible = true;
            pMesh.position.copy(position);
            pMesh.scale.setScalar(0.6 * scale + Math.random() * 0.6 * scale);
            pMesh.material.color.setHex(color);
            pMesh.material.emissive.setHex(color);
            pMesh.material.opacity = 1;

            const velocity = new THREE.Vector3(
                (Math.random() - 0.5) * 10 * scale,
                (Math.random() - 0.2) * 8 * scale,
                (Math.random() - 0.5) * 10 * scale
            );

            this.particles.push({
                mesh: pMesh,
                velocity: velocity,
                life: 0.6 + Math.random() * 0.6
            });
        }
    }

    _updateParticles(dt) {
        for (let i = this.particles.length - 1; i >= 0; i--) {
            const p = this.particles[i];
            p.mesh.position.addScaledVector(p.velocity, dt);
            p.life -= dt;

            // fade and reduce emissive
            const fade = Math.max(0, p.life / 1.2);
            p.mesh.material.opacity = fade;
            p.mesh.material.emissiveIntensity = fade * 2;

            if (p.life <= 0) {
                p.mesh.visible = false;
                this.particlePool.push(p.mesh);
                this.particles.splice(i, 1);
            }
        }
    }

    // ---------- Post Processing (bloom) ----------
    _initPostProcessing() {
        try {
            // These classes should be imported by the host script (ES modules)
            this.composer = new EffectComposer(this.renderer);
            this.composer.addPass(new RenderPass(this.scene, this.camera));

            const bloomPass = new UnrealBloomPass(
                new THREE.Vector2(this.canvas.width, this.canvas.height),
                0.9, // strength
                0.4, // radius
                0.2  // threshold
            );
            // slightly stronger bloom when enraged later
            this.composer.addPass(bloomPass);

            this._bloomPass = bloomPass;
        } catch (err) {
            console.warn("Post-processing not initialized. Make sure EffectComposer, RenderPass and UnrealBloomPass are imported.", err);
            this.composer = null;
            this._bloomPass = null;
        }
    }

    // ---------- Input ----------
    _setupEventListeners() {
        this.keyDownHandler = (e) => {
            this.keysPressed[e.key.toLowerCase()] = true;
            // Player shooting on space
            if (e.code === 'Space' && this.player.shootTimer <= 0) {
                this._spawnPlayerProjectile();
                this.player.shootTimer = this.player.shootCooldown;
            }
        };
        this.keyUpHandler = (e) => delete this.keysPressed[e.key.toLowerCase()];
        window.addEventListener('keydown', this.keyDownHandler);
        window.addEventListener('keyup', this.keyUpHandler);
    }

    _removeEventListeners() {
        window.removeEventListener('keydown', this.keyDownHandler);
        window.removeEventListener('keyup', this.keyUpHandler);
    }

    // ---------- Projectiles ----------
    _spawnPlayerProjectile() {
        const geometry = new THREE.SphereGeometry(0.28, 8, 8);
        const material = new THREE.MeshStandardMaterial({ color: 0x00d8ff, emissive: 0x006f88, emissiveIntensity: 1.6 });
        const projectile = new THREE.Mesh(geometry, material);
        projectile.position.copy(this.player.mesh.position).add(new THREE.Vector3(0, 1.2, -0.5));

        const velocity = new THREE.Vector3(0, 0, BATTLE_CONFIG.PLAYER_PROJECTILE_SPEED);

        this.projectiles.push({
            mesh: projectile,
            velocity: velocity,
            owner: 'player',
            damage: BATTLE_CONFIG.PLAYER_PROJECTILE_DAMAGE
        });
        this.scene.add(projectile);
    }

    _spawnMissile(isFast) {
        const missile = new THREE.Mesh(
            new THREE.CylinderGeometry(0.28, 0.28, 1.2, 12),
            new THREE.MeshStandardMaterial({ color: 0xff9800, emissive: 0xff5500, metalness: 0.3 })
        );
        missile.position.copy(this.architect.mesh.position);
        // aim at player
        const targetPosition = this.player.mesh.position.clone();
        missile.lookAt(targetPosition);
        const velocity = new THREE.Vector3();
        missile.getWorldDirection(velocity);
        velocity.multiplyScalar(isFast ? 46 : 28);

        this.projectiles.push({
            mesh: missile,
            velocity: velocity,
            owner: 'architect',
            damage: BATTLE_CONFIG.PROJECTILE_DAMAGE_MISSILE
        });
        this.scene.add(missile);
    }

    _spawnLaser() {
        const laser = new THREE.Mesh(
            new THREE.BoxGeometry(0.34, 0.34, 3.2),
            new THREE.MeshBasicMaterial({ color: 0xff2dff })
        );
        laser.position.copy(this.architect.mesh.position);
        const dir = this.player.mesh.position.clone().sub(laser.position).normalize();
        const velocity = dir.multiplyScalar(72);

        this.projectiles.push({
            mesh: laser,
            velocity: velocity,
            owner: 'architect',
            damage: BATTLE_CONFIG.PROJECTILE_DAMAGE_LASER
        });
        this.scene.add(laser);
    }

    _spawnShardVolley() {
        for (let i = 0; i < 3; i++) {
            const shard = new THREE.Mesh(
                new THREE.BoxGeometry(0.36, 0.36, 0.36),
                new THREE.MeshBasicMaterial({ color: 0xff66ff })
            );
            shard.position.copy(this.architect.mesh.position);
            const spread = new THREE.Vector3(
                (Math.random() - 0.5) * 16,
                (Math.random() - 0.5) * 6,
                -28
            );

            this.projectiles.push({
                mesh: shard,
                velocity: spread,
                owner: 'architect',
                damage: BATTLE_CONFIG.PROJECTILE_DAMAGE_SHARD
            });
            this.scene.add(shard);
        }
    }

    // ---------- New Boss Attacks ----------
    _spawnShockwave() {
        // expanding ring represented by thin cylinder that expands and damages on contact
        const ring = new THREE.Mesh(
            new THREE.RingGeometry(0.6, 0.8, 64),
            new THREE.MeshBasicMaterial({ color: 0x00e6ff, side: THREE.DoubleSide, transparent: true, opacity: 0.9 })
        );
        ring.rotation.x = -Math.PI / 2;
        ring.position.copy(this.architect.mesh.position);
        ring.userData = { radius: 0.8, growth: 25, life: 1.4, damage: 20 };
        this.scene.add(ring);

        // we use projectiles array to track it (owner 'architect-shockwave')
        this.projectiles.push({
            mesh: ring,
            velocity: new THREE.Vector3(0, 0, 0),
            owner: 'architect-shockwave',
            damage: ring.userData.damage,
            life: ring.userData.life
        });
    }

    _spawnWarpDash() {
        // warp: teleport near player then dash forward
        // visual teleport: small burst then reposition
        this._spawnParticles(this.architect.mesh.position, 0xff66ff, 25, 1.6);

        // choose a position behind player
        const target = this.player.mesh.position.clone().add(new THREE.Vector3((Math.random() - 0.5) * 4, 0, 6));
        // reposition instantly (teleport)
        this.architect.mesh.position.copy(target);
        // dash forward (push a fast projectile simulating ram)
        const dashDir = this.player.mesh.position.clone().sub(this.architect.mesh.position).normalize();
        this.projectiles.push({
            mesh: null, // not visible as projectile, but use for timing
            velocity: dashDir.clone().multiplyScalar(0),
            owner: 'architect-dash',
            damage: 25,
            life: 0.45,
            source: this.architect.mesh
        });
        this._spawnParticles(this.architect.mesh.position, 0xff00ff, 40, 1.2);
    }

    _spawnTargetBeam() {
        // windup indicator (thin cylinder) that stays for 0.9s then fires high-damage fast beam
        const indicator = new THREE.Mesh(
            new THREE.CylinderGeometry(0.15, 0.15, 1.5, 8),
            new THREE.MeshBasicMaterial({ color: 0x00f0ff, transparent: true, opacity: 0.7 })
        );
        indicator.position.copy(this.architect.mesh.position);
        indicator.lookAt(this.player.mesh.position);
        this.scene.add(indicator);

        // schedule beam as a projectile with small delay
        this.projectiles.push({
            mesh: indicator,
            velocity: new THREE.Vector3(0, 0, 0),
            owner: 'architect-beam-windup',
            damage: 35,
            life: 0.9 // when life ends, fire beam
        });
    }

    // ---------- Game updates ----------
    _updatePlayer(dt) {
        // movement
        if (this.keysPressed['arrowleft'] || this.keysPressed['a']) {
            this.player.mesh.position.x -= this.player.moveSpeed * dt;
        }
        if (this.keysPressed['arrowright'] || this.keysPressed['d']) {
            this.player.mesh.position.x += this.player.moveSpeed * dt;
        }
        if (this.keysPressed['arrowup'] || this.keysPressed['w']) {
            this.player.mesh.position.z -= this.player.depthSpeed * dt;
        }
        if (this.keysPressed['arrowdown'] || this.keysPressed['s']) {
            this.player.mesh.position.z += this.player.depthSpeed * dt;
        }

        this.player.mesh.position.x = THREE.MathUtils.clamp(this.player.mesh.position.x, -12, 12);
        this.player.mesh.position.z = THREE.MathUtils.clamp(this.player.mesh.position.z, -10, 15);

        if (this.player.shootTimer > 0) this.player.shootTimer -= dt;

        // UI update: flash when hit
        const hitSince = performance.now() / 1000 - this.state.lastPlayerHitTime;
        if (hitSince < 0.25 && this.ui.container) {
            this.ui.container.style.filter = `brightness(${1.2 + (0.25 - hitSince) * 1.6})`;
        } else if (this.ui.container) {
            this.ui.container.style.filter = 'none';
        }
    }

    _updateArchitect(dt) {
        const elapsed = this.clock.getElapsedTime();
        this.architect.mesh.position.y = 5 + Math.sin(elapsed * 1.1) * 1.0;
        this.architect.mesh.rotation.y += dt * 0.35;
        this.architect.shards.forEach((shard, i) => {
            const angle = (i / this.architect.shards.length) * Math.PI * 2 + elapsed * 0.8;
            shard.position.set(Math.cos(angle) * 4.4, Math.sin(angle * 2.4) * 1.2, Math.sin(angle) * 4.4);
            shard.rotation.y += dt * 1.0;
        });

        // Attack selection
        this.architect.attackTimer -= dt;
        if (this.architect.attackTimer <= 0) {
            const attackType = Math.random();
            if (this.state.isEnraged) {
                if (attackType > 0.7) this._spawnWarpDash();
                else if (attackType > 0.4) this._spawnMissile(true);
                else if (attackType > 0.15) this._spawnShockwave();
                else this._spawnTargetBeam();
                this.architect.attackTimer = BATTLE_CONFIG.BOSS_ATTACK_TIMER_ENRAGED + Math.random() * 0.6;
            } else {
                if (attackType > 0.55) this._spawnMissile(false);
                else if (attackType > 0.25) this._spawnLaser();
                else this._spawnShardVolley();
                this.architect.attackTimer = BATTLE_CONFIG.BOSS_ATTACK_TIMER_NORMAL + Math.random() * 1.2;
            }
        }

        // Enraged state check
        if (!this.state.isEnraged && this.state.bossHealth < this.state.bossMaxHealth / 2) {
            this.state.isEnraged = true;
            // visual: core turns deep red/pink and increase bloom
            const core = this.architect.mesh.children[0];
            if (core && core.material) {
                core.material.color.setHex(0xff0044);
                core.material.emissive.setHex(0x660022);
                core.material.emissiveIntensity = 2.2;
            }
            if (this._bloomPass) {
                this._bloomPass.strength = 1.4;
                this._bloomPass.radius = 0.6;
            }
        }
    }

    _updateProjectiles(dt) {
        const playerBox = new THREE.Box3().setFromObject(this.player.mesh);
        const architectBox = new THREE.Box3().setFromObject(this.architect.mesh);

        for (let i = this.projectiles.length - 1; i >= 0; i--) {
            const proj = this.projectiles[i];
            // life-driven actions (windups, beams, dash timer)
            if (proj.life !== undefined) {
                proj.life -= dt;
            }

            // specific behaviors
            if (proj.owner === 'architect-beam-windup' && proj.life <= 0) {
                // replace windup with a real fast beam projectile
                const beam = new THREE.Mesh(
                    new THREE.CylinderGeometry(0.18, 0.18, 3.2, 8),
                    new THREE.MeshBasicMaterial({ color: 0x00f0ff })
                );
                beam.position.copy(proj.mesh.position);
                beam.quaternion.copy(proj.mesh.quaternion);
                // fire forward toward player
                const dir = this.player.mesh.position.clone().sub(beam.position).normalize();
                const velocity = dir.multiplyScalar(120);
                this.projectiles.push({
                    mesh: beam,
                    velocity: velocity,
                    owner: 'architect',
                    damage: proj.damage
                });
                this.scene.add(beam);
                // cleanup windup mesh
                if (proj.mesh) this.scene.remove(proj.mesh);
                this.projectiles.splice(i, 1);
                continue;
            }

            if (proj.owner === 'architect-dash') {
                // dash life ends -> apply damage if close
                if (proj.life <= 0) {
                    const dashSource = proj.source;
                    if (dashSource) {
                        const dashBox = new THREE.Box3().setFromObject(dashSource);
                        if (dashBox.intersectsBox(playerBox)) {
                            this.state.playerHealth -= proj.damage;
                            this.state.lastPlayerHitTime = performance.now() / 1000;
                            this._spawnParticles(this.player.mesh.position, 0xffffff, 22, 1.0);
                            if (this.state.playerHealth <= 0) { this.stop(false); return; }
                        }
                    }
                    this.projectiles.splice(i, 1);
                }
                continue;
            }

            // update position if present
            if (proj.mesh && proj.velocity) {
                proj.mesh.position.addScaledVector(proj.velocity, dt);
            }

            // Shockwave expands visually and hits if radius crosses player
            if (proj.owner === 'architect-shockwave') {
                // we fake expansion by increasing geometry scale based on life
                const lifeFactor = Math.max(0, proj.life);
                const progress = 1.4 - lifeFactor; // grows over time
                proj.mesh.scale.setScalar(1 + progress * 12);
                // check player collision by distance
                const dx = proj.mesh.position.clone().setY(0).distanceTo(this.player.mesh.position.clone().setY(0));
                const ringRadius = 0.8 + progress * 12;
                if (Math.abs(dx - ringRadius) < 1.2) {
                    // hit
                    this.state.playerHealth -= proj.damage;
                    this.state.lastPlayerHitTime = performance.now() / 1000;
                    this._spawnParticles(this.player.mesh.position, 0xffffff, 18, 1.0);
                    if (this.state.playerHealth <= 0) { this.stop(false); return; }
                    // avoid multi-hits: mark damage done by setting damage 0
                    proj.damage = 0;
                }
                if (proj.life <= 0) {
                    this.scene.remove(proj.mesh);
                    this.projectiles.splice(i, 1);
                }
                continue;
            }

            // --- Collisions for normal projectiles ---
            if (!proj.mesh) continue;

            const projBox = new THREE.Box3().setFromObject(proj.mesh);

            if (proj.owner === 'architect' && projBox.intersectsBox(playerBox)) {
                this.state.playerHealth -= proj.damage;
                this.state.lastPlayerHitTime = performance.now() / 1000;
                this._spawnParticles(proj.mesh.position, 0xffffff, 12);
                
                this.scene.remove(proj.mesh);
                this.projectiles.splice(i, 1);
                if (this.state.playerHealth <= 0) { this.stop(false); return; }
                continue;

            } else if (proj.owner === 'player' && projBox.intersectsBox(architectBox)) {
                this.state.bossHealth -= proj.damage;
                this._spawnParticles(proj.mesh.position, 0xff66ff, 18, 1.0);
                
                this.scene.remove(proj.mesh);
                this.projectiles.splice(i, 1);

                // boss death
                if (this.state.bossHealth <= 0) {
                    this._spawnParticles(this.architect.mesh.position, 0xff00ff, 160, 2.6);
                    this.stop(true);
                    return;
                }
                continue;
            }
            // bounds cleanup
            if (proj.mesh && proj.mesh.position) {
                if (proj.mesh.position.z < -80 || proj.mesh.position.z > 80 ||
                    Math.abs(proj.mesh.position.x) > 200 || Math.abs(proj.mesh.position.y) > 200) {
                    if (proj.mesh) this.scene.remove(proj.mesh);
                    this.projectiles.splice(i, 1);
                    continue;
                }
            }
        }
    }

    // ---------- UI ----------
    _createUI() {
        // simple DOM overlay for health bars
        const container = document.createElement('div');
        container.style.position = 'absolute';
        container.style.left = '12px';
        container.style.top = '12px';
        container.style.width = '320px';
        container.style.fontFamily = 'Inter, Arial, sans-serif';
        container.style.pointerEvents = 'none';
        container.style.zIndex = 9999;

        // Player bar
        const playerBarWrap = document.createElement('div');
        playerBarWrap.style.marginBottom = '8px';
        const playerLabel = document.createElement('div');
        playerLabel.textContent = 'PLAYER';
        playerLabel.style.color = '#00f0ff';
        playerLabel.style.fontSize = '12px';
        playerBarWrap.appendChild(playerLabel);
        const playerBar = document.createElement('div');
        playerBar.style.width = '320px';
        playerBar.style.height = '14px';
        playerBar.style.background = '#111';
        playerBar.style.borderRadius = '8px';
        playerBar.style.overflow = 'hidden';
        const playerFill = document.createElement('div');
        playerFill.style.height = '100%';
        playerFill.style.width = '100%';
        playerFill.style.background = 'linear-gradient(90deg, #00f0ff, #0066ff)';
        playerFill.style.transition = 'width 0.2s ease';
        playerBar.appendChild(playerFill);
        playerBarWrap.appendChild(playerBar);
        container.appendChild(playerBarWrap);

        // Boss bar
        const bossBarWrap = document.createElement('div');
        const bossLabel = document.createElement('div');
        bossLabel.textContent = 'ARCHITECT';
        bossLabel.style.color = '#ff4dd9';
        bossLabel.style.fontSize = '12px';
        bossBarWrap.appendChild(bossLabel);
        const bossBar = document.createElement('div');
        bossBar.style.width = '480px';
        bossBar.style.height = '18px';
        bossBar.style.background = '#111';
        bossBar.style.borderRadius = '10px';
        bossBar.style.overflow = 'hidden';
        const bossFill = document.createElement('div');
        bossFill.style.height = '100%';
        bossFill.style.width = '100%';
        bossFill.style.background = 'linear-gradient(90deg, #ff2dff, #ff66ff)';
        bossFill.style.transition = 'width 0.2s ease';
        bossBar.appendChild(bossFill);
        bossBarWrap.appendChild(bossBar);
        bossBarWrap.style.marginTop = '6px';
        container.appendChild(bossBarWrap);

        document.body.appendChild(container);

        this.ui = {
            container,
            playerFill,
            bossFill
        };
    }

    _updateUI() {
        if (!this.ui || !this.ui.playerFill) return;
        const p = Math.max(0, this.state.playerHealth) / this.state.playerMaxHealth;
        const b = Math.max(0, this.state.bossHealth) / this.state.bossMaxHealth;

        this.ui.playerFill.style.width = `${Math.round(p * 100)}%`;
        this.ui.bossFill.style.width = `${Math.round(b * 100)}%`;

        // boss low-health flash
        if (b < 0.25) {
            this.ui.bossFill.style.boxShadow = '0 0 12px 4px rgba(255,45,255,0.35)';
            if (Math.random() < 0.01) this.ui.bossFill.style.transform = 'translateY(-2px)';
            else this.ui.bossFill.style.transform = 'translateY(0)';
        } else {
            this.ui.bossFill.style.boxShadow = 'none';
        }
    }

    // ---------- Main Loop ----------
    animate() {
        this.animationFrameId = requestAnimationFrame(() => this.animate());
        const dt = this.clock.getDelta();

        this._updatePlayer(dt);
        this._updateArchitect(dt);
        this._updateProjectiles(dt);
        this._updateParticles(dt);
        this._updateUI();

        // render with composer if available
        if (this.composer) {
            this.composer.render(dt);
        } else {
            this.renderer.render(this.scene, this.camera);
        }
    }
}
